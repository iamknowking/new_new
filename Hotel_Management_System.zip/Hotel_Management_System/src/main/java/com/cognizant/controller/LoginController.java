package com.cognizant.controller;
  
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.dao.LoginDetailsRepository;
import com.cognizant.model.LoginDetails;
  
@Controller 
public class LoginController {
  

@Autowired 
LoginDetailsRepository loginRepo;


	@PostMapping("/")
	public String GetLogin(@ModelAttribute LoginDetails login,Model model,HttpServletRequest request,BindingResult result) {
		HttpSession session=request.getSession();
		LoginDetails l=this.loginRepo.findByStaffUsernameAndStaffUser(login.getStaffUsername(),login.getStaffUser());
		LoginDetails l1=this.loginRepo.findByStaffLocationAndStaffPassword(login.getStaffLocation(),login.getStaffPassword());
		LoginDetails l2=this.loginRepo.findByStaffUsernameAndStaffPassword(login.getStaffUsername(),login.getStaffPassword());
		LoginDetails l3=this.loginRepo.findByStaffLocationAndStaffUser(login.getStaffLocation(),login.getStaffUser());
		if(l==null||l1==null||l2==null||l3==null)
		{
			model.addAttribute("valid","Incorrect Username or Password");
			return "index";
		}
		else {
			session.setAttribute("staffUsername",login.getStaffUsername());
			if(login.getStaffUser().equals("Owner"))
			{
				return "Login_Details_form";
			}
			else if(login.getStaffUser().equals("Manager"))
			{
				return "Staff_Details";
			}
			else if(login.getStaffUser().equals("Receptionist"))
			{
				return "Customer_Details_form";
			}
		}
		return "index";
		
		
}
  
	@RequestMapping("/signout")
	public String signout(HttpSession session)
	{
		session.setAttribute("staffUsername", null);
		session.invalidate();
		return "index";
	}
	
}