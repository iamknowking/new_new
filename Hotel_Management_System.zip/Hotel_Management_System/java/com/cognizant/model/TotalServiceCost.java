package com.cognizant.model;

import java.util.List;

public class TotalServiceCost {
	private List<ServiceRequest> list;
	private double total;
	public List<ServiceRequest> getList() {
		return list;
	}
	public void setList(List<ServiceRequest> list) {
		this.list = list;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
}
