package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table
public class LoginDetails{

	@Id
	@NotEmpty(message="Value should not be null")
	private String staffId;
	
	@Column(length = 30)
	@NotEmpty(message="Value should not be null")
	private String staffName;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String staffUsername;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String staffPassword;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String staffLocation;
   
	@Column(length = 20)
	@NotEmpty(message="Value should not be null")
	private String staffUser;

	public LoginDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoginDetails(@NotEmpty(message = "Value should not be null") String staffId,
			@NotEmpty(message = "Value should not be null") String staffName,
			@NotEmpty(message = "Value should not be null") String staffUsername,
			@NotEmpty(message = "Value should not be null") String staffPassword,
			@NotEmpty(message = "Value should not be null") String staffLocation,
			@NotEmpty(message = "Value should not be null") String staffUser) {
		super();
		this.staffId = staffId;
		this.staffName = staffName;
		this.staffUsername = staffUsername;
		this.staffPassword = staffPassword;
		this.staffLocation = staffLocation;
		this.staffUser = staffUser;
	}

	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public String getStaffUsername() {
		return staffUsername;
	}

	public void setStaffUsername(String staffUsername) {
		this.staffUsername = staffUsername;
	}

	public String getStaffPassword() {
		return staffPassword;
	}

	public void setStaffPassword(String staffPassword) {
		this.staffPassword = staffPassword;
	}

	public String getStaffLocation() {
		return staffLocation;
	}

	public void setStaffLocation(String staffLocation) {
		this.staffLocation = staffLocation;
	}

	public String getStaffUser() {
		return staffUser;
	}

	public void setStaffUser(String staffUser) {
		this.staffUser = staffUser;
	}

	@Override
	public String toString() {
		return "LoginDetails [staffId=" + staffId + ", staffName=" + staffName + ", staffUsername=" + staffUsername
				+ ", staffPassword=" + staffPassword + ", staffLocation=" + staffLocation + ", staffUser=" + staffUser
				+ "]";
	}

	
}