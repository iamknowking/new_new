package com.cognizant.model;

import java.util.List;

public class ServiceRequestModel{
	private List<ServiceRequest> serviceList;
	private double totalcost;
	public List<ServiceRequest> getServiceList() {
		return serviceList;
	}
	public void setServiceList(List<ServiceRequest> serviceList) {
		this.serviceList = serviceList;
	}
	public double getTotalcost() {
		return totalcost;
	}
	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}
	
}