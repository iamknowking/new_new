package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table
public class ServiceRequest{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int serviceId;
	
	@Column(length=30)
	@NotEmpty(message="Value should not be null")
	private String customerName;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String roomNumber;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String staffId;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String staffName;
	
	@Column(length = 30)
	@NotEmpty(message="Value should not be null")
	private String serviceDetails;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String status;
	
	@Column(length = 5)
	@NotNull(message="Value should not be null")
	private double cost;

	public ServiceRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceRequest(int serviceId, @NotEmpty(message = "Value should not be null") String customerName,
			@NotEmpty(message = "Value should not be null") String roomNumber,
			@NotEmpty(message = "Value should not be null") String staffId,
			@NotEmpty(message = "Value should not be null") String staffName,
			@NotEmpty(message="Value should not be null") String serviceDetails,
			@NotEmpty(message = "Value should not be null") String status,
			@NotNull(message = "Value should not be null") double cost) {
		super();
		this.serviceId = serviceId;
		this.customerName = customerName;
		this.roomNumber = roomNumber;
		this.staffId = staffId;
		this.staffName = staffName;
		this.serviceDetails = serviceDetails;
		this.status = status;
		this.cost = cost;
	}



	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public String getServiceDetails() {
		return serviceDetails;
	}

	public void setServiceDetails(String serviceDetails) {
		this.serviceDetails = serviceDetails;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "ServiceRequest [serviceId=" + serviceId + ", customerName=" + customerName + ", roomNumber="
				+ roomNumber + ", staffId=" + staffId + ", staffName=" + staffName + ", serviceDetails="
				+ serviceDetails + ", status=" + status + ", cost=" + cost + "]";
	}

	



	



	
}