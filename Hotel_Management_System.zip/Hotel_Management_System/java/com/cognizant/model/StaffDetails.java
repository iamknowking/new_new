package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


@Entity
@Table
public class StaffDetails {
		
		@Id
		@Column
		@NotEmpty(message="Value should not be null")
		private String staffId;
		
		@Column
		@NotEmpty(message="Value should not be null")
		private String staffName;
		
		@Pattern(regexp="[7-9]{1}[0-9]{9}",message="Mobile number should be 10 digits and starting with digit 7/8/9")
		private String staffPhone;
	
		@Column
		@NotEmpty(message="Value should not be null")
		private String staffAddress;
		
		@Column
		@NotNull(message="Value should not be null")
		private int staffSalary;
		
		@Column
		@NotEmpty(message="Value should not be null")
		private String staffLocation;
		
		public StaffDetails() {
			super();
			// TODO Auto-generated constructor stub
		}

		public StaffDetails(@NotEmpty(message = "Value should not be null") String staffId,
				@NotEmpty(message = "Value should not be null") String staffName,
				@NotEmpty(message = "Value should not be null") String staffPhone,
				@NotEmpty(message = "Value should not be null") String staffAddress,
				@NotEmpty(message = "Value should not be null") int staffSalary,
				@NotEmpty(message = "Value should not be null") String staffLocation) {
			super();
			this.staffId = staffId;
			this.staffName = staffName;
			this.staffPhone = staffPhone;
			this.staffAddress = staffAddress;
			this.staffSalary = staffSalary;
			this.staffLocation = staffLocation;
		}

		public String getStaffId() {
			return staffId;
		}

		public void setStaffId(String staffId) {
			this.staffId = staffId;
		}

		public String getStaffName() {
			return staffName;
		}

		public void setStaffName(String staffName) {
			this.staffName = staffName;
		}

		public String getStaffPhone() {
			return staffPhone;
		}

		public void setStaffPhone(String staffPhone) {
			this.staffPhone = staffPhone;
		}

		public String getStaffAddress() {
			return staffAddress;
		}

		public void setStaffAddress(String staffAddress) {
			this.staffAddress = staffAddress;
		}

		public int getStaffSalary() {
			return staffSalary;
		}

		public void setStaffSalary(int staffSalary) {
			this.staffSalary = staffSalary;
		}

		public String getStaffLocation() {
			return staffLocation;
		}

		public void setStaffLocation(String staffLocation) {
			this.staffLocation = staffLocation;
		}
		
		


		@Override
		public String toString() {
			return "StaffDetails [staffId=" + staffId + ", staffName=" + staffName + ", staffPhone=" + staffPhone
					+ ", staffAddress=" + staffAddress + ", staffSalary=" + staffSalary + ", staffLocation="
					+ staffLocation + "]";
		}

		
}