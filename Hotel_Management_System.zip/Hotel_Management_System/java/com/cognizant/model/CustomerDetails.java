package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table
public class CustomerDetails{

	@Id 
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String customerId;
	
	@Column(length = 30)
	@NotEmpty(message="Value should not be null")
	private String customerName;
	
	@Column(length = 10)
	@Size(max=10)
	@Pattern(regexp="(^$|[0-9]{10})",message="Mobile number should be 10 digits and starting with digit 7/8/9")
	private String customerPhone;
	
	@Column(length = 20)
	@NotEmpty(message="Value should not be null")
	private String customerEmailId;
	
	@Column(length = 100)
	@NotEmpty(message="Value should not be null")
	private String customerAddress;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String customerMembership;
   
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String customerMembershipNo;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String checkInDate;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String checkOutDate;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String noOfVisits;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String roomNumber;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String location;
	

	public CustomerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public CustomerDetails(@NotEmpty(message = "Value should not be null") String customerId,
			@NotEmpty(message = "Value should not be null") String customerName,
			@NotEmpty(message = "Value should not be null") String customerPhone,
			@NotEmpty(message = "Value should not be null") String customerEmailId,
			@NotEmpty(message = "Value should not be null") String customerAddress,
			@NotEmpty(message = "Value should not be null") String customerMembership,
			@NotEmpty(message = "Value should not be null") String customerMembershipNo,
			@NotEmpty(message = "Value should not be null") String checkInDate,
			@NotEmpty(message = "Value should not be null") String checkOutDate,
			@NotEmpty(message = "Value should not be null") String noOfVisits,
			@NotEmpty(message = "Value should not be null") String roomNumber,
			@NotEmpty(message = "Value should not be null") String location) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerEmailId = customerEmailId;
		this.customerAddress = customerAddress;
		this.customerMembership = customerMembership;
		this.customerMembershipNo = customerMembershipNo;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.noOfVisits = noOfVisits;
		this.roomNumber = roomNumber;
		this.location = location;
	}



	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerMembership() {
		return customerMembership;
	}

	public void setCustomerMembership(String customerMembership) {
		this.customerMembership = customerMembership;
	}

	public String getCustomerMembershipNo() {
		return customerMembershipNo;
	}

	public void setCustomerMembershipNo(String customerMembershipNo) {
		this.customerMembershipNo = customerMembershipNo;
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	public String getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public String getNoOfVisits() {
		return noOfVisits;
	}

	public void setNoOfVisits(String noOfVisits) {
		this.noOfVisits = noOfVisits;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "CustomerDetails [customerId=" + customerId + ", customerName=" + customerName + ", customerPhone="
				+ customerPhone + ", customerEmailId=" + customerEmailId + ", customerAddress=" + customerAddress
				+ ", customerMembership=" + customerMembership + ", customerMembershipNo=" + customerMembershipNo
				+ ", checkInDate=" + checkInDate + ", checkOutDate=" + checkOutDate + ", noOfVisits=" + noOfVisits
				+ ", roomNumber=" + roomNumber + ", location=" + location + "]";
	}

	
	
	
}