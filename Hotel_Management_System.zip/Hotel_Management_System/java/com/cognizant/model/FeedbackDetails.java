package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table
public class FeedbackDetails{

	@Id
	@NotEmpty(message="Value should not be null")
	private String customerId;
	
	@Column(length = 30)
	@NotEmpty(message="Value should not be null")
	private String customerName;
	
	@Column(length = 10)
	@NotEmpty(message="Value should not be null")
	private String location;
   
	@Column(length = 200)
	@NotEmpty(message="Value should not be null")
	private String feedback;

	public FeedbackDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FeedbackDetails(@NotEmpty(message = "Value should not be null") String customerId,
			@NotEmpty(message = "Value should not be null") String customerName,
			@NotEmpty(message = "Value should not be null") String location,
			@NotEmpty(message = "Value should not be null") String feedback) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.location = location;
		this.feedback = feedback;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	@Override
	public String toString() {
		return "FeedbackDetails [customerId=" + customerId + ", customerName=" + customerName + ", location=" + location
				+ ", feedback=" + feedback + "]";
	}

	
}