package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table
public class StaffAttendance {
		
		@Id
		@Column
		@NotEmpty(message="Value should not be null")
		private String staffId;
		
		@Column
		@NotEmpty(message="Value should not be null")
		private String staffName;
		
		@Column
		@NotEmpty(message="Value should not be null")
		private String staffLocation;
		
		@Column
		@NotNull(message="Value should not be null")
		private int staffSalary;
		
		@Column
		@NotEmpty(message="Value should not be null")
		private String noOfHoliday;
	
		@Column
		@NotEmpty(message="Value should not be null")
		private String noOfDays;

		public StaffAttendance() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		public StaffAttendance(@NotEmpty(message = "Value should not be null") String staffId,
				@NotEmpty(message = "Value should not be null") String staffName,
				@NotEmpty(message = "Value should not be null") String staffLocation,
				@NotEmpty(message = "Value should not be null") int staffSalary,
				@NotEmpty(message = "Value should not be null") String noOfHoliday,
				@NotEmpty(message = "Value should not be null") String noOfDays) {
			super();
			this.staffId = staffId;
			this.staffName = staffName;
			this.staffLocation = staffLocation;
			this.staffSalary = staffSalary;
			this.noOfHoliday = noOfHoliday;
			this.noOfDays = noOfDays;
		}

		public String getStaffId() {
			return staffId;
		}

		public void setStaffId(String staffId) {
			this.staffId = staffId;
		}

		public String getStaffName() {
			return staffName;
		}

		public void setStaffName(String staffName) {
			this.staffName = staffName;
		}

		public String getStaffLocation() {
			return staffLocation;
		}

		public void setStaffLocation(String staffLocation) {
			this.staffLocation = staffLocation;
		}

		public int getStaffSalary() {
			return staffSalary;
		}

		public void setStaffSalary(int staffSalary) {
			this.staffSalary = staffSalary;
		}

		public String getNoOfHoliday() {
			return noOfHoliday;
		}

		public void setNoOfHoliday(String noOfHoliday) {
			this.noOfHoliday = noOfHoliday;
		}

		public String getNoOfDays() {
			return noOfDays;
		}

		public void setNoOfDays(String noOfDays) {
			this.noOfDays = noOfDays;
		}

		@Override
		public String toString() {
			return "StaffDetails [staffId=" + staffId + ", staffName=" + staffName + ", staffLocation=" + staffLocation
					+ ", staffSalary=" + staffSalary + ", noOfHoliday=" + noOfHoliday + ", noOfDays=" + noOfDays + "]";
		}

		
		
		

		
}