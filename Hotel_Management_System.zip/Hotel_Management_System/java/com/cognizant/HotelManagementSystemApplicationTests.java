package com.cognizant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.cognizant.controller.ManagerController;
import com.cognizant.controller.OwnerController;
import com.cognizant.controller.ReceptionistController;
import com.cognizant.dao.CustomerDetailsRepository;
import com.cognizant.dao.FeedbackDetailsRepository;
import com.cognizant.dao.LoginDetailsRepository;
import com.cognizant.dao.ServiceRequestRepository;
import com.cognizant.dao.StaffAttendanceRepository;
import com.cognizant.dao.StaffDetailsRepository;
import com.cognizant.model.CustomerDetails;
import com.cognizant.model.FeedbackDetails;
import com.cognizant.model.LoginDetails;
import com.cognizant.model.StaffAttendance;
import com.cognizant.model.StaffDetails;
import com.cognizant.service.CustomerDetailsService;
import com.cognizant.service.ServiceRequestService;
import com.cognizant.service.StaffDetailsService;

@SpringBootTest
class HotelManagementSystemApplicationTests {
	@Autowired
	private OwnerController ownerController;

	@Autowired
	private ManagerController managerController;

	@Autowired
	private ReceptionistController receptionistController;

	@Autowired
	private LoginDetailsRepository logindetailsrepository;

	@Autowired
	private FeedbackDetailsRepository feedbackrepository;

	@Autowired
	private CustomerDetailsRepository customerrepository;
	
	@Autowired
	private StaffDetailsRepository staffrepository;
	
	@Autowired
	private StaffAttendanceRepository staffattendanccerepository;
	
	@Autowired
	private ServiceRequestRepository servicerepository;

	@Autowired
	private CustomerDetailsService customerservice;
	
	@Autowired
	private StaffDetailsService staffservice;
	
	@Autowired
	private ServiceRequestService serviceRequestService;

	@Test
	@Order(1)
	public void testHomepage() {

		assertEquals("index", ownerController.homepage());
	}

	@Test
	@Order(2)
	public void testLoginForm() {

		assertEquals("Login_Details_form", ownerController.loginForm());
	}

	@Test
	@Order(3)
	public void testEditStaff() {

		assertEquals("Edit_Staff_Details", ownerController.editStaff());
	}

	@Test
	@Order(4)
	public void testEditCustomer() {

		assertEquals("Find_Details_Customer", ownerController.editCustomer());
	}

	@Test
	@Order(5)
	public void testFindStaffOwner() {

		assertEquals("Find_Details_Staff", ownerController.findStaffOwner());
	}

	@Test
	@Order(6)
	public void testReturnStaffAttendancePage() {

		assertEquals("Add_StaffAttendanceManager", managerController.returnStaffAttendancePage());
	}

	@Test
	@Order(7)
	public void testGetStaffDetails() {

		assertEquals("Staff_Details", managerController.getStaffDetails());
	}

	@Test
	@Order(8)
	public void testGetAttendance() {

		assertEquals("Find_AttendanceManager", managerController.getAttendance());
	}

	@Test
	@Order(9)
	public void testGetCustomerReceptionDetails() {
		assertEquals("Customer_Details_form", receptionistController.getCustomerReceptionDetails());
	}

	@Test
	@Order(10)
	public void testGetFeedback() {

		assertEquals("Feedback", receptionistController.getFeedback());
	}

	@Test
	@Order(11)
	public void testgetServiceRequest() {

		assertEquals("ServiceRequest", receptionistController.getServiceRequest());
	}
	
	@Test
	@Order(12)
	public void testGetSearch() {

		assertEquals("Bill_SearchManager", managerController.GetSearch());
	}
	
	@Test
	@Order(13)
	public void testPostLoginDetails() {
		LoginDetails login=logindetailsrepository.save(new LoginDetails("M5","Amatya","amartya","amartya@12","Mumbai","Manager"));
		assertThat(login.getStaffId()).isEqualTo("M5");
	}
	
	@Test
	@Order(14)
	public void testPostStaffDetails() {
		StaffDetails staff=staffrepository.save(new StaffDetails("S5","Aman","9879500369","12 Aman Society,Mumbai",13020,"Mumbai"));
		assertThat(staff.getStaffId()).isEqualTo("S5");
	}
	
	@Test
	@Order(15)
	public void testPostCustomerDetails() {
		CustomerDetails customer=customerrepository.save(new CustomerDetails("5","Ajay","9879500596","ajay@gmail.com","21 Ajay Apartments,Mumbai","No","NA","21/03/2021","24/03/2021","2","108","Mumbai"));
		assertThat(customer.getCustomerId()).isEqualTo("5");
	}
	
	@Test
	@Order(16)
	public void testPostStaffAttendance() {
		StaffAttendance staffAttendance=staffattendanccerepository.save(new StaffAttendance("S5","Aman","Pune",13020,"2","30"));
		assertThat(staffAttendance.getStaffId()).isEqualTo("S5");
	}
	
	@Test
	@Order(17)
	public void testAddFeedback() {
		FeedbackDetails feedback=feedbackrepository.save(new FeedbackDetails("5","Ajay","Mumbai","Good Service"));
		assertThat(feedback.getCustomerId()).isEqualTo("5");
	}
	
	
	@Test
	@Order(18)
	public void testFindFeedback() {
		List<FeedbackDetails> list = this.feedbackrepository.findByLocation("Mumbai");
		assertThat(list).size().isGreaterThan(0);
	}
	

	@Test
	@Order(19)
	public void testFindCustomerDetails() {
		List<CustomerDetails> list = this.customerrepository.findByLocation("Mumbai");
		assertThat(list).size().isGreaterThanOrEqualTo(0);
	}
	
	@Test
	@Order(20)
	public void testfindDetails() {
		List<StaffDetails> list = this.staffrepository.findBystaffLocation("Mumbai");
		assertThat(list).size().isGreaterThanOrEqualTo(0);
	}
	
	@Test
	@Order(21)
	public void testfindStaffAttendance() {
		List<StaffAttendance> list = this.staffattendanccerepository.findBystaffLocation("Pune");
		assertThat(list).size().isGreaterThanOrEqualTo(0);
	}
	
	@Test
    @Rollback(true)
    @Order(22)
    public void testDeleteCustomerReception() {
        CustomerDetails customer = customerrepository.findBycustomerId("5");
        customerservice.deleteCustomer(customer.getCustomerId()); 
        CustomerDetails deletedUser = customerrepository.findBycustomerId("5");
        assertThat(deletedUser).isNull();       
    }
	
	@Test
    @Rollback(true)
    @Order(23)
    public void testDeleteStaffManager() {
        StaffDetails staff = staffrepository.findBystaffId("S5");
        staffservice.deleteStaffManager(staff.getStaffId()); 
        StaffDetails deletedUser = staffrepository.findBystaffId("S5");
        assertThat(deletedUser).isNull();       
    }

}
