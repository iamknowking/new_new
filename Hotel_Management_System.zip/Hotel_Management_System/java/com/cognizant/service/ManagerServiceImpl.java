/*package com.cognizant.service;

import com.cognizant.dao.ManagerRepository;
import com.cognizant.model.LoginDetails;
import com.cognizant.model.Manager;

public class ManagerServiceImpl implements ManagerService {
	
	private ManagerRepository managerRepo;
	
	public Manager validate(LoginDetails login) {
		
		Manager manager = managerRepo.findByUsernameAndPassword(login.getStaffUsername(), login.getStaffPassword());
		return manager;
	}
	
}
*/