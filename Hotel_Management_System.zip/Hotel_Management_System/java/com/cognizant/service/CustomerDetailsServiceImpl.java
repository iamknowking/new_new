package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.dao.CustomerDetailsRepository;
import com.cognizant.model.CustomerDetails;


@Transactional
@Service("customerDetailsService")
public class CustomerDetailsServiceImpl implements CustomerDetailsService {

	@Autowired
	private CustomerDetailsRepository customerDetailsRepository;
	
	public CustomerDetails update(CustomerDetails customerDetails) {
		return customerDetailsRepository.save(customerDetails);
	}
	
	public void deleteCustomer(String customerId) {
		customerDetailsRepository.deleteById(customerId);
	}
	
	public void deleteCustomerManager(String customerId) {
		customerDetailsRepository.deleteById(customerId);
	}

	public void deleteCustomerReception(String customerId) {
		customerDetailsRepository.deleteById(customerId);
		
	}

	
}