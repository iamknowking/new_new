package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.dao.StaffDetailsRepository;
import com.cognizant.model.StaffDetails;

@Transactional
@Service("staffDetailsService")
public class StaffDetailsServiceImpl implements StaffDetailsService {

	@Autowired
	private StaffDetailsRepository staffDetailsRepository;
	
	public StaffDetails save(StaffDetails staffDetails) {
		return staffDetailsRepository.save(staffDetails);
	}
	
	public void delete(String staffId) {
		staffDetailsRepository.deleteById(staffId);
	}
	
	public void deleteStaffManager(String staffId) {
		staffDetailsRepository.deleteById(staffId);
	}

	
}