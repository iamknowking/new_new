package com.cognizant.service;

import com.cognizant.model.CustomerDetails;

public interface CustomerDetailsService {

	public CustomerDetails update(CustomerDetails customer);
	
	public void deleteCustomer(String customerId);

	public void deleteCustomerManager(String customerId);

	public void deleteCustomerReception(String customerId);


}