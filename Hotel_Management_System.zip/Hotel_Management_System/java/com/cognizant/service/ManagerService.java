/*package com.cognizant.service;

import org.springframework.stereotype.Service;

import com.cognizant.model.LoginDetails;
import com.cognizant.model.Manager;

@Service
public interface ManagerService {
	public Manager validate(LoginDetails login);
}
*/