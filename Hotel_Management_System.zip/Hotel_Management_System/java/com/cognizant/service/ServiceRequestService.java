package com.cognizant.service;

public interface ServiceRequestService {

	public void deleteService(String customerName);
}
