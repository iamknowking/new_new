package com.cognizant.service;

import com.cognizant.model.StaffDetails;

public interface StaffDetailsService {

	public StaffDetails save(StaffDetails staff);
	
	public void delete(String staffId);
	
	public void deleteStaffManager(String staffId);

	
}