package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.dao.ServiceRequestRepository;


@Transactional
@Service("serviceRequestService")
public class ServiceRequestServiceImpl implements ServiceRequestService {

	@Autowired
	private ServiceRequestRepository serviceRepository;
	
	
	public void deleteService(String customerName) {
		serviceRepository.deleteBycustomerName(customerName);
	}
	
}