package com.cognizant.dao;


import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.model.CustomerDetails;

public interface CustomerDetailsRepository extends CrudRepository<CustomerDetails,String> {

	List<CustomerDetails> findByLocation(String Location);
	
	List<CustomerDetails> findByCustomerId(String customerId);

	CustomerDetails findBycustomerId(String customerId);
	
//	List<CustomerDetails> findBycustomerId(String customerId);

}