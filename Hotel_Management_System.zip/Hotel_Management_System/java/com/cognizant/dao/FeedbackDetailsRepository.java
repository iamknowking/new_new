package com.cognizant.dao;


import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.model.FeedbackDetails;

public interface FeedbackDetailsRepository extends CrudRepository<FeedbackDetails,String> {
	List<FeedbackDetails> findByLocation(String location);
}