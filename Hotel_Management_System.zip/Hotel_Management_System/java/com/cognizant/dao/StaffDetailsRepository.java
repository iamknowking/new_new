package com.cognizant.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.model.StaffDetails;

public interface StaffDetailsRepository extends CrudRepository<StaffDetails,String>{
	List<StaffDetails> findBystaffLocation(String staffLocation);
	
	StaffDetails findBystaffId(String staffId);
	
	List<StaffDetails> findByStaffId(String staffId);
}