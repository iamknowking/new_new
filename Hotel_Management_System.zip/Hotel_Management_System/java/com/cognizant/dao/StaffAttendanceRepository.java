package com.cognizant.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.model.StaffAttendance;

public interface StaffAttendanceRepository extends CrudRepository<StaffAttendance,String>{
	List<StaffAttendance> findBystaffLocation(String staffLocation);

	List<StaffAttendance> findByStaffId(String staffId);
}