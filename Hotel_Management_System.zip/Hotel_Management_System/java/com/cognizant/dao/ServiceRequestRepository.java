package com.cognizant.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.model.ServiceRequest;

public interface ServiceRequestRepository extends CrudRepository<ServiceRequest,Integer>{
	
	
	List<ServiceRequest> findByCustomerName(String customerName);

	void deleteBycustomerName(String customerName);

	ServiceRequest findByServiceId(int serviceId);
		
}