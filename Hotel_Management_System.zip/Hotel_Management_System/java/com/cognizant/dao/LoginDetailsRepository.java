package com.cognizant.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.LoginDetails;

@Repository
public interface LoginDetailsRepository extends CrudRepository<LoginDetails, String> {
	
	List<LoginDetails> findBystaffId(String staffId);

	LoginDetails findByStaffUsernameAndStaffUser(String staffUsername, String staffUser);
	LoginDetails findByStaffLocationAndStaffPassword(String staffLocation,String staffPassword);
	LoginDetails findByStaffUsernameAndStaffPassword(String staffUsername,String staffPassword);
	LoginDetails findByStaffLocationAndStaffUser(String staffLocation,String staffUser);
}
