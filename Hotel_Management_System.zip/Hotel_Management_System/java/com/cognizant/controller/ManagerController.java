package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dao.CustomerDetailsRepository;
import com.cognizant.dao.ServiceRequestRepository;
import com.cognizant.dao.StaffAttendanceRepository;
import com.cognizant.dao.StaffDetailsRepository;
import com.cognizant.model.CustomerDetails;
import com.cognizant.model.ServiceRequest;
import com.cognizant.model.ServiceRequestModel;
import com.cognizant.model.StaffAttendance;
import com.cognizant.model.StaffDetails;
import com.cognizant.service.CustomerDetailsService;
import com.cognizant.service.StaffDetailsService;

@Controller
public class ManagerController {
	
	@Autowired
	private StaffDetailsRepository staffRepo;
	
	@Autowired
	private StaffDetailsService staffDetailsService;
	
	@Autowired
	private CustomerDetailsRepository customerRepo;
	
	@Autowired
	private CustomerDetailsService customerDetailsService;
	
	@Autowired
	private StaffAttendanceRepository staffAttendanceRepo;
	
	@Autowired
	private ServiceRequestRepository serviceRepository;
	
	@Autowired
	private CustomerDetailsRepository customerRepository;
	
	@RequestMapping(path="/addstaffattendance", method=RequestMethod.GET)
	public String returnStaffAttendancePage() {
		return "Add_StaffAttendanceManager";
	}
	
	@RequestMapping(path="/addstaffmanager", method=RequestMethod.GET)
	public String getStaffDetails() {
		return "Staff_Details";
	}
	
	@RequestMapping(path="/addcustomermanager", method=RequestMethod.GET)
	public String getCustomerDetails() {
		return "Customer_Details_Manager";
	}
	
	
	@RequestMapping(path="/findattendance", method=RequestMethod.GET)
	public String getAttendance() {
		return "Find_AttendanceManager";
	}
	
	@RequestMapping(path="/addstaff", method=RequestMethod.POST)
		public String postStaffDetails(@ModelAttribute StaffDetails details,Model model) {
			List<StaffDetails> list=staffRepo.findByStaffId(details.getStaffId());
			if(list.isEmpty()) {
			staffRepo.save(details);
			return "Staff_Details";
			}
			else
			{
				model.addAttribute("message","Staff Id already Exits.");
				return "Staff_Details";
			}
	}
	
	@RequestMapping(path="/clearservicemanager",method =RequestMethod.GET)
	public String findServie(@RequestParam(required=false,name="customerName") String search,Model model)
	{
		List<ServiceRequest> list=this.serviceRepository.findByCustomerName(search);
		double totalcost=0.0;
		for(ServiceRequest service: list)
		{
			totalcost=totalcost+service.getCost();
		}
		ServiceRequestModel servicemodel=new ServiceRequestModel();
		servicemodel.setServiceList(list);
		servicemodel.setTotalcost(totalcost);
		model.addAttribute("servicemodel",servicemodel);
		model.addAttribute("list",list);
		return "ServiceRequest_ClearManager";
	}
	
	@RequestMapping(path="/addcustomer",method=RequestMethod.POST)
	public String addCustomer(@ModelAttribute CustomerDetails customerlogin,Model model){
		List<CustomerDetails> list=customerRepo.findByCustomerId(customerlogin.getCustomerId());
		if(list.isEmpty()) {
		 customerRepo.save(customerlogin);
		 return "Customer_Details_Manager"; 
		}
		else
		{
			model.addAttribute("message","Customer Id already Exits.");
			return "Customer_Details_Manager";
		}
  }
	
	@RequestMapping(path="/findstaffmanager",method =RequestMethod.GET)
	public String findDetailsManager(@RequestParam(required=false,name="staffLocation") String search,Model model)
	{
		List<StaffDetails> list=this.staffRepo.findBystaffLocation(search);
		model.addAttribute("list",list);
		return "Find_Details_StaffManager";
	}
	
	@RequestMapping(value = "deletestaffmanager/{staffId}", method = RequestMethod.GET)
	public String deleteStaffManager(@PathVariable("staffId") String staffId) {
		staffDetailsService.deleteStaffManager(staffId);
		return "Staff_Details";
	}
	
	@RequestMapping(path="/findcustomermanager",method =RequestMethod.GET)
	public String findCustomerDetailsManager(@RequestParam(required=false,name="location") String search,Model model)
	{
		List<CustomerDetails> list=this.customerRepo.findByLocation(search);
		model.addAttribute("list",list);
		return "Find_Details_CustomerManager";
	}
	
	@RequestMapping(value = "deletecustomermanager/{customerId}", method = RequestMethod.GET)
	public String deleteCustomerManager(@PathVariable("customerId") String customerId) {
		customerDetailsService.deleteCustomerManager(customerId);
		return "Customer_Details_Manager";
	}
	
	@RequestMapping(path="/addstaffattendancemanager", method=RequestMethod.POST)
	public String postStaffAttendance(@ModelAttribute("staffAttendance") StaffAttendance staffAttendance) {
		staffAttendanceRepo.save(staffAttendance);
		return "Add_StaffAttendanceManager";
	}
	
	@RequestMapping(path="/findattendancemanager",method =RequestMethod.GET)
	public String findStaffAttendanceManager(@RequestParam(required=false,name="staffLocation") String search,Model model)
	{
		List<StaffAttendance> list=this.staffAttendanceRepo.findBystaffLocation(search);
		model.addAttribute("list",list);
		return "Find_AttendanceManager";
	}
	
	@RequestMapping(value="/editstaffmanager/{staffId}",method = RequestMethod.GET)
	public String index(@PathVariable String staffId,Model model) {
    	StaffDetails staff=staffRepo.findBystaffId(staffId);
    	System.out.println(staff);
    	 model.addAttribute("command",staff);  
    	return "Edit_Staff_DetailsManager";
	}

	@RequestMapping(value = "/updatesuccessmanager", method = RequestMethod.POST)
	public String update(@ModelAttribute("staff") StaffDetails staff) {
		staffDetailsService.save(staff);
		System.out.println("Updated");
		return "Find_Details_StaffManager";
	}
	
	@RequestMapping(value="/editcustomermanager/{customerId}",method = RequestMethod.GET)
	public String getCustomerDetails(@PathVariable String customerId,Model mod) {
    	CustomerDetails customer=customerRepo.findBycustomerId(customerId);
    	 mod.addAttribute("command",customer);  
    	return "Edit_Customer_DetailsManager";
	}

	@RequestMapping(value = "/updatecustomermanager", method = RequestMethod.POST)
	public String updateCustomer(@ModelAttribute("customer") CustomerDetails customer) {
		customerRepo.save(customer);
		return "Find_Details_CustomerManager";
	}
	
	@RequestMapping(path="/calculatesalary",method =RequestMethod.GET)
	public String calculateSalary(@RequestParam(required=false,name="staffLocation") String search,Model model)
	{
		List<StaffAttendance> list=this.staffAttendanceRepo.findBystaffLocation(search);
		model.addAttribute("list",list);
		return "Staff_Salary";
	}
	
	@RequestMapping(value="/editattendancemanager/{staffId}",method = RequestMethod.GET)
	public String getStaffAttendance(@PathVariable("staffId") String staffId,Model mod2) {
		List<StaffAttendance> staffattendance=staffAttendanceRepo.findByStaffId(staffId);
    	 mod2.addAttribute("commander",staffattendance.get(0));  
    	return "Edit_StaffAttendance_Manager";
	}

	@RequestMapping(value = "/editattendance", method = RequestMethod.POST)
	public String updateStaffAttendance(@ModelAttribute("staffattendance") StaffAttendance staffattendance) {
		staffAttendanceRepo.save(staffattendance);
		return "Find_AttendanceManager";
	}
	
	@RequestMapping(value="/getsearchmanager")
	public String GetSearch() {
	return "Bill_SearchManager";	
	}


@RequestMapping(value="/searchbillmanager",method = RequestMethod.GET)
public String getBill(@RequestParam(required=false,name="customerId") String search,Model model)
{
	CustomerDetails list=this.customerRepository.findBycustomerId(search);
	model.addAttribute("command",list);
	return "BillManager";
}
}