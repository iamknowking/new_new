package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dao.CustomerDetailsRepository;
import com.cognizant.dao.FeedbackDetailsRepository;
import com.cognizant.dao.LoginDetailsRepository;
import com.cognizant.dao.StaffAttendanceRepository;
import com.cognizant.dao.StaffDetailsRepository;
import com.cognizant.model.CustomerDetails;
import com.cognizant.model.FeedbackDetails;
import com.cognizant.model.LoginDetails;
import com.cognizant.model.StaffAttendance;
import com.cognizant.model.StaffDetails;
import com.cognizant.service.CustomerDetailsService;
import com.cognizant.service.StaffDetailsService;

@Controller
public class OwnerController {
  
	
	@Autowired
	private StaffDetailsRepository staffRepo;

	@Autowired
	private CustomerDetailsRepository customerRepo;
	
	@Autowired
	private FeedbackDetailsRepository feedbackRepo;
	
	@Autowired
	private StaffDetailsService staffDetailsService;
	
	@Autowired
	private CustomerDetailsService customerDetailsService;

	@Autowired
	private StaffAttendanceRepository staffAttendanceRepo;
	
	@Autowired
	private LoginDetailsRepository loginRepo;;
	
	
	@GetMapping("/")
	public String homepage() {
		return "index";
	}
	
	@RequestMapping("/form")
	public String loginForm() {
		return "Login_Details_form";
	}
	
	@RequestMapping("/editstaff")
	public String editStaff() {
		return "Edit_Staff_Details";
	}
	
	@RequestMapping("/findcustomerowner")
	public String editCustomer() {
		return "Find_Details_Customer";
	}
	
	@RequestMapping("/findstaffowner")
	public String findStaffOwner() {
		return "Find_Details_Staff";
	}
  
	
	  @RequestMapping(path="/logindetails",method=RequestMethod.POST) 
	  public String postLoginDetails(@ModelAttribute LoginDetails login,Model model){
		  List<LoginDetails> list=loginRepo.findBystaffId(login.getStaffId());
		  if(list.isEmpty()) {
			  	loginRepo.save(login); 
			  	return "Login_Details_form"; 
	  }
		  else
		  {
			  model.addAttribute("message","Staff Id already Exits.");
				return "Login_Details_form";
		  }
	  }
	 
	
	@RequestMapping(path="/findstaff",method =RequestMethod.GET)
	public String findDetails(@RequestParam(required=false,name="staffLocation") String search,Model model)
	{
		List<StaffDetails> list=this.staffRepo.findBystaffLocation(search);
		model.addAttribute("list",list);
		return "Find_Details_Staff";
	}
	
	@RequestMapping(path="/findcustomer",method =RequestMethod.GET)
	public String findCustomerDetails(@RequestParam(required=false,name="location") String search,Model model)
	{
		List<CustomerDetails> list=this.customerRepo.findByLocation(search);
		model.addAttribute("list",list);
		return "Find_Details_Customer";
	}
	
	@RequestMapping(path="/findfeedback",method =RequestMethod.GET)
	public String findFeedback(@RequestParam(required=false,name="location") String search,Model model)
	{
		List<FeedbackDetails> list=this.feedbackRepo.findByLocation(search);
		model.addAttribute("list",list);
		return "View_Feedback";
	}
	
    @RequestMapping(value="/editstaff/{staffId}",method = RequestMethod.GET)
	public String index(@PathVariable String staffId,Model model) {
    	StaffDetails staff=staffRepo.findBystaffId(staffId);
    	System.out.println(staff);
    	 model.addAttribute("command",staff);  
    	return "Edit_Staff_Details";
	}

	@RequestMapping(value = "/updatesuccess", method = RequestMethod.POST)
	public String update(@ModelAttribute("staff") StaffDetails staff) {
		staffDetailsService.save(staff);
		System.out.println("Updated");
		return "Find_Details_Staff";
	}
	
	@RequestMapping(value="/editcustomer/{customerId}",method = RequestMethod.GET)
	public String getCustomerDetails(@PathVariable String customerId,Model mod) {
    	CustomerDetails customer=customerRepo.findBycustomerId(customerId);
    	 mod.addAttribute("command",customer);  
    	return "Edit_Customer_Details";
	}

	@RequestMapping(value = "/updatecustomer", method = RequestMethod.POST)
	public String updateCustomer(@ModelAttribute("customer") CustomerDetails customer) {
		customerRepo.save(customer);
		return "Find_Details_Customer";
	}


	
	@RequestMapping(value = "delete/{staffId}", method = RequestMethod.GET)
	public String delete(@PathVariable("staffId") String staffId) {
		staffDetailsService.delete(staffId);
		return "Login_Details_form";
	}
	
	@RequestMapping(value = "deletecustomer/{customerId}", method = RequestMethod.GET)
	public String deleteCustomer(@PathVariable("customerId") String customerId) {
		customerDetailsService.deleteCustomer(customerId);
		return "Login_Details_form";
	}
	
	@RequestMapping(path="/findstaffattendance",method =RequestMethod.GET)
	public String findStaffAttendance(@RequestParam(required=false,name="staffLocation") String search,Model model)
	{
		List<StaffAttendance> list=this.staffAttendanceRepo.findBystaffLocation(search);
		model.addAttribute("list",list);
		return "Find_Attendance";
	}
}