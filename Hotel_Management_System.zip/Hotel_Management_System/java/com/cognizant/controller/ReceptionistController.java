package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dao.CustomerDetailsRepository;
import com.cognizant.dao.FeedbackDetailsRepository;
import com.cognizant.dao.ServiceRequestRepository;
import com.cognizant.model.CustomerDetails;
import com.cognizant.model.FeedbackDetails;
import com.cognizant.model.ServiceRequest;
import com.cognizant.model.ServiceRequestModel;
import com.cognizant.service.CustomerDetailsService;
import com.cognizant.service.ServiceRequestService;

@Controller
public class ReceptionistController {
  
	@Autowired
	private CustomerDetailsRepository customerRepository;
	
	@Autowired
	private FeedbackDetailsRepository feedbackRepository;
	
	@Autowired
	private CustomerDetailsService customerDetailsService;
	
	@Autowired
	private ServiceRequestService serviceRequestService;
	
	@Autowired
	private ServiceRequestRepository serviceRepository;

	
	@RequestMapping(path="/addcustomerreceptionist", method=RequestMethod.GET)
	public String getCustomerReceptionDetails() {
		return "Customer_Details_form";
	}
	
	@RequestMapping(path="/getfeedback", method=RequestMethod.GET)
	public String getFeedback() {
		return "Feedback";
	}
	
	@RequestMapping(path="/servicerequest", method=RequestMethod.GET)
	public String getServiceRequest() {
		return "ServiceRequest";
	}
	
//	@GetMapping(value="/findcustomer")
//	public String findCustomer() {
//		return "Find_Details_CustomerReception";
//	}
	
	@RequestMapping(path="/customerdetailsreceptionist",method=RequestMethod.POST)
	public String postCustomerDetails(@ModelAttribute CustomerDetails customerlogin,Model model) {
	List<CustomerDetails> list=customerRepository.findByCustomerId(customerlogin.getCustomerId());
	if(list.isEmpty()) {
	 customerRepository.save(customerlogin);
	 return "Customer_Details_form"; 
	}
	else
	{
		model.addAttribute("message","Customer Id already Exits.");
		return "Customer_Details_form";
	}
	}
	
	@RequestMapping(path="/findcustomerreceptionist",method =RequestMethod.GET)
	public String findCustomerReceptionDetails(@RequestParam(required=false,name="location") String search,Model model)
	{
		List<CustomerDetails> list=this.customerRepository.findByLocation(search);
		model.addAttribute("list",list);
		return "Find_Details_CustomerReception";
	}
	
	@RequestMapping(value = "/deletecustomerreceptionist/{customerId}", method = RequestMethod.GET)
	public String deleteCustomerReception(@PathVariable("customerId") String customerId) {
		customerDetailsService.deleteCustomerReception(customerId);
		return "Customer_Details_form";
	}
	
	@RequestMapping(value="/editcustomerreceptionist/{customerId}",method = RequestMethod.GET)
	public String getCustomerDetails(@PathVariable String customerId,Model mod) {
    	CustomerDetails customer=customerRepository.findBycustomerId(customerId);
    	 mod.addAttribute("command",customer);  
    	return "Edit_CustomerDetailsReceptionist";
	}

	@RequestMapping(value = "/updatecustomerreceptionist", method = RequestMethod.POST)
	public String updateCustomer(@ModelAttribute("customer") CustomerDetails customer) {
		customerRepository.save(customer);
		return "Find_Details_CustomerReception";
	}
	
	@RequestMapping(value="/addfeedback",method = RequestMethod.POST)
	public String addFeedback(@ModelAttribute FeedbackDetails feedback){
		 feedbackRepository.save(feedback);
		 return "Feedback";  
		}
	
	@RequestMapping(path="/addservicerequest",method=RequestMethod.POST)
	public String addServiceRequest(@ModelAttribute ServiceRequest service){
	 serviceRepository.save(service);
	 return "ServiceRequest";  
	}
	
	@RequestMapping(path="/clearservice",method =RequestMethod.GET)
	public String findServie(@RequestParam(required=false,name="customerName") String search,Model model)
	{
		List<ServiceRequest> list=this.serviceRepository.findByCustomerName(search);
		double totalcost=0.0;
		for(ServiceRequest service: list)
		{
			totalcost=totalcost+service.getCost();
		}
		ServiceRequestModel servicemodel=new ServiceRequestModel();
		servicemodel.setServiceList(list);
		servicemodel.setTotalcost(totalcost);
		model.addAttribute("servicemodel",servicemodel);
		model.addAttribute("list",list);
		return "ServiceRequest_Clear";
	}
	
	@RequestMapping(value="/editservice/{serviceId}",method = RequestMethod.GET)
	public String getServiceRequest(@PathVariable("serviceId") int serviceId,Model mod1) {
    	ServiceRequest service=serviceRepository.findByServiceId(serviceId);
    	mod1.addAttribute("list", service);
    	return "Clear_Service";
	}

	@RequestMapping(value = "/serviceupdate", method = RequestMethod.POST)
	public String updateService(@ModelAttribute("service") ServiceRequest service) {
		serviceRepository.save(service);
		return "ServiceRequest_Clear";
	}
	
	@RequestMapping(value = "deleteservice/{customerName}", method = RequestMethod.GET)
	public String deleteService(@PathVariable("customerName") String customerName) {
		serviceRequestService.deleteService(customerName);
		return "ServiceRequest";
	}
	
	@RequestMapping(value="/getsearch")
		public String GetSearch() {
		return "Bill_Search";	
		}
	
	
	@RequestMapping(value="/searchbill",method = RequestMethod.GET)
	public String getBill(@RequestParam(required=false,name="customerId") String search,Model model)
	{
		CustomerDetails list=this.customerRepository.findBycustomerId(search);
		model.addAttribute("command",list);
		return "Bill";
	}
	
}